
clear; clc;

Nlist = [10 20 40 80];
nN    = length(Nlist);
errL2 = zeros(1,nN);   errH1 = zeros(1,nN);

for k = 1:nN
    N  = Nlist(k);
    h  = 1/(N+1);
    x  = (0:(N+1))'*h;          
    xi = x(2:N+1);
    A = (2/h)*eye(N) - (1/h)*(diag(ones(N-1,1),1) + diag(ones(N-1,1),-1));%刚度矩阵
    M  = (h/6)*(4*eye(N) + diag(ones(N-1,1),1) + diag(ones(N-1,1),-1));
    b  = M*ffun(xi);
    b(1) = b(1) + (h/6)*ffun(x(1));
    b(N) = b(N) + (h/6)*ffun(x(end));
    U = A \ b;
    errL2(k) = computeError(U, x, h, 0);
    errH1(k) = computeError(U, x, h, 1);
end

ordL2 = log(errL2(1:nN-1)./errL2(2:nN)) ./ log(Nlist(2:nN)./Nlist(1:nN-1));
ordH1 = log(errH1(1:nN-1)./errH1(2:nN)) ./ log(Nlist(2:nN)./Nlist(1:nN-1));

fprintf('   N      L2 error      order     H1 error      order\n');
fprintf('---------------------------------------------------------\n');
for k = 1:nN
    if k == 1
        fprintf('%4d   %.4e       --     %.4e       --\n', Nlist(k), errL2(k), errH1(k));
    else
        fprintf('%4d   %.4e   %6.3f   %.4e   %6.3f\n', ...
                Nlist(k), errL2(k), ordL2(k-1), errH1(k), ordH1(k-1));
    end
end

function y = ffun(x)
    y = -(2*cos(x) - (x-1).*sin(x));
end

function y = uexact(x)
    y = (x-1).*sin(x);
end

function y = duexact(x)
    y = sin(x) + (x-1).*cos(x);
end

function err = computeError(U, x, h, iflag) % iflag = 0: L2范数;   iflag = 1: H1范数
    N  = length(U);
    Uf = [0; U; 0];
    m  = 20;
    dx = h/m;
    e2 = 0;
    for j = 1:N+1
        xs = x(j) + dx*(0:m);
        uh = Uf(j)*(x(j+1)-xs)/h + Uf(j+1)*(xs-x(j))/h;
        ue = uexact(xs);
        if iflag == 0
            g = (ue - uh).^2;
        else
            duh = (Uf(j+1)-Uf(j))/h;
            g   = (ue-uh).^2 + (duexact(xs)-duh).^2;
        end
        e2 = e2 + dx*( sum(g) - 0.5*(g(1) + g(m+1)) );
    end
    err = sqrt(e2);
end
