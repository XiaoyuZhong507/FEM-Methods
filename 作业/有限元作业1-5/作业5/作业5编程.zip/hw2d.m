
clear; clc; close all;

%%问题数据
uexact = @(x) (x-1).*sin(x);
duex   = @(x) sin(x) + (x-1).*cos(x);
ffun   = @(x) -(2*cos(x) - (x-1).*sin(x));

%%自检: 中心差分验证 -u'' = f
H = 1e-4;  x0 = 0.37;
lap = (uexact(x0+H) - 2*uexact(x0) + uexact(x0-H))/H^2;
fprintf('自检: %.3e (应为 1e-8 量级)\n', -lap - ffun(x0));

%% 4点 Gauss-Legendre 求积
ga = sqrt(3/7 - (2/7)*sqrt(6/5));
gb = sqrt(3/7 + (2/7)*sqrt(6/5));
xg = zeros(4,1);  wg = zeros(4,1);
xg(1) = 0.5 - gb/2;  wg(1) = (18 - sqrt(30))/72;
xg(2) = 0.5 - ga/2;  wg(2) = (18 + sqrt(30))/72;
xg(3) = 0.5 + ga/2;  wg(3) = (18 + sqrt(30))/72;
xg(4) = 0.5 + gb/2;  wg(4) = (18 - sqrt(30))/72;

%%验证: 打印 N=2 的 P2 整体刚度阵
[pv, tv, Kv, Fv] = assembleP2(2, ffun, xg, wg);
fprintf('\n验证: N=2 时整体刚度阵 (5x5, h=0.5):\n');
for i = 1:5
    fprintf('  ');
    for j = 1:5
        fprintf('%10.4f', Kv(i,j));
    end
    fprintf('\n');
end

%%刚度矩阵计算
Nlist = [10 20 40 80];
eL2b = zeros(4,1);  eH1b = zeros(4,1);
for lev = 1:4
    N = Nlist(lev);
    [pb, tb, Kb, Fb] = assembleP2(N, ffun, xg, wg);
    uhb = solvefe(Kb, Fb);
    [eL2b(lev), eH1b(lev)] = comperr(pb, tb, uhb, 2, uexact, duex, xg, wg);
end

fprintf('\n误差与收敛阶：');
fprintf('   N     L2 error      order     H1 error      order\n');
for lev = 1:4
    if lev == 1
        fprintf('%5d   %.4e        -     %.4e        -\n', Nlist(lev), eL2b(lev), eH1b(lev));
    else
        r = log(Nlist(lev)/Nlist(lev-1));
        fprintf('%5d   %.4e   %6.2f    %.4e   %6.2f\n', Nlist(lev), ...
            eL2b(lev), log(eL2b(lev-1)/eL2b(lev))/r, ...
            eH1b(lev), log(eH1b(lev-1)/eH1b(lev))/r);
    end
end


%%局部函数
function [p, t, K, F] = assembleP1(N, ffun, xg, wg)
% P1: 全局结点 k=1..N+1 位于 (k-1)h; 单元 I_j 连接 [j, j+1]
h = 1/N;  M = N + 1;
p = zeros(M,1);
for k = 1:M
    p(k) = (k-1)*h;
end
t = zeros(N,2);
for j = 1:N
    t(j,1) = j;  t(j,2) = j+1;
end
K = zeros(M,M);  F = zeros(M,1);
for j = 1:N
    a1 = t(j,1);  a2 = t(j,2);
    xl = p(a1);
    Fe1 = 0;  Fe2 = 0;
    for q = 1:4
        fq = ffun(xl + h*xg(q));
        Fe1 = Fe1 + wg(q)*h*fq*(1 - xg(q));   % hat phi_1 = 1-s
        Fe2 = Fe2 + wg(q)*h*fq*xg(q);         % hat phi_2 = s
    end
    F(a1) = F(a1) + Fe1;
    F(a2) = F(a2) + Fe2;
    K(a1,a1) = K(a1,a1) + 1/h;
    K(a1,a2) = K(a1,a2) - 1/h;
    K(a2,a1) = K(a2,a1) - 1/h;
    K(a2,a2) = K(a2,a2) + 1/h;
end
end

function [p, t, K, F] = assembleP2(N, ffun, xg, wg)
% P2: 全局结点 k=1..2N+1 位于 (k-1)h/2 (奇数端点, 偶数中点)
% 单元 I_j 连接 [2j-1, 2j, 2j+1]; 局部阵 (1/3h)[7 -8 1; -8 16 -8; 1 -8 7]
h = 1/N;  M = 2*N + 1;
p = zeros(M,1);
for k = 1:M
    p(k) = (k-1)*h/2;
end
t = zeros(N,3);
for j = 1:N
    t(j,1) = 2*j-1;  t(j,2) = 2*j;  t(j,3) = 2*j+1;
end
K = zeros(M,M);  F = zeros(M,1);
c = 1/(3*h);
for j = 1:N
    a1 = t(j,1);  a2 = t(j,2);  a3 = t(j,3);
    xl = p(a1);
    Fe1 = 0;  Fe2 = 0;  Fe3 = 0;
    for q = 1:4
        s  = xg(q);
        fq = ffun(xl + h*s);
        Fe1 = Fe1 + wg(q)*h*fq*(2*s-1)*(s-1);   % psi_1
        Fe2 = Fe2 + wg(q)*h*fq*4*s*(1-s);       % psi_2
        Fe3 = Fe3 + wg(q)*h*fq*s*(2*s-1);       % psi_3
    end
    F(a1) = F(a1) + Fe1;
    F(a2) = F(a2) + Fe2;
    F(a3) = F(a3) + Fe3;
    K(a1,a1) = K(a1,a1) + 7*c;
    K(a1,a2) = K(a1,a2) - 8*c;
    K(a1,a3) = K(a1,a3) + c;
    K(a2,a1) = K(a2,a1) - 8*c;
    K(a2,a2) = K(a2,a2) + 16*c;
    K(a2,a3) = K(a2,a3) - 8*c;
    K(a3,a1) = K(a3,a1) + c;
    K(a3,a2) = K(a3,a2) - 8*c;
    K(a3,a3) = K(a3,a3) + 7*c;
end
end

function uh = solvefe(K, F)
% 消去 Dirichlet: 首末结点(1 与 M)取 0, 解内部结点 2..M-1 的方程组
M = length(F);
nI = M - 2;
Kr = zeros(nI, nI);
Fr = zeros(nI, 1);
for a = 1:nI
    Fr(a) = F(a+1);
    for b = 1:nI
        Kr(a,b) = K(a+1, b+1);
    end
end
ui = Kr \ Fr;
uh = zeros(M,1);
for a = 1:nI
    uh(a+1) = ui(a);
end
end

function [eL2, eH1] = comperr(p, t, uh, porder, uexact, duex, xg, wg)
% 逐单元 4 点 Gauss 求积: ||u-uh||_L2 与 ||u-uh||_H1
ne = size(t,1);
s2L = 0;  s2H = 0;
for j = 1:ne
    a1 = t(j,1);  a2 = t(j,2);
    xl = p(a1);
    if porder == 1
        h  = p(a2) - p(a1);
        u1 = uh(a1);  u2 = uh(a2);  u3 = 0;
    else
        a3 = t(j,3);
        h  = p(a3) - p(a1);
        u1 = uh(a1);  u2 = uh(a2);  u3 = uh(a3);
    end
    for q = 1:4
        s  = xg(q);
        xq = xl + h*s;
        if porder == 1
            uhq = u1*(1-s) + u2*s;
            duh = (u2 - u1)/h;
        else
            uhq = u1*(2*s-1)*(s-1) + u2*4*s*(1-s) + u3*s*(2*s-1);
            duh = (u1*(4*s-3) + u2*(4-8*s) + u3*(4*s-1))/h;
        end
        d  = uexact(xq) - uhq;
        dg = duex(xq) - duh;
        s2L = s2L + wg(q)*h*d^2;
        s2H = s2H + wg(q)*h*(d^2 + dg^2);
    end
end
eL2 = sqrt(s2L);
eH1 = sqrt(s2H);
end

