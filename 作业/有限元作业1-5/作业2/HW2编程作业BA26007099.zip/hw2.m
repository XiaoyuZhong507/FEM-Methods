
clear; clc; close all;

u    = @(x) x.^2 .* (x-1).^2;
du   = @(x) 4*x.^3 - 6*x.^2 + 2*x;
f    = @(x) -(12*x.^2 - 12*x + 2);



Intu  = 1/5 - 1/2 + 1/3;
Nlist = [10 20 40 80];
nN    = length(Nlist);
errL2 = zeros(1,nN);
errH1 = zeros(1,nN);


gp2 = [0.5-sqrt(3)/6; 0.5+sqrt(3)/6];
gw2 = [0.5; 0.5];
gp5 = 0.5 + 0.5*[-0.906179845938664; -0.538469310105683; 0; ...
                  0.538469310105683;   0.906179845938664];
gw5 = 0.5*[ 0.236926885056189;  0.478628670499366; 0.568888888888889; ...
            0.478628670499366;  0.236926885056189];

fprintf('=========================================================\n');
fprintf('   N      L2 error     order     H1 error     order\n');
fprintf('---------------------------------------------------------\n');

for k = 1:nN
    N  = Nlist(k);   h = 1/N;
    node = (0:N)' * h;
    ne   = N;

    
    K = zeros(N+1);   b = zeros(N+1,1);
    for e = 1:ne
        idx = [e, e+1];
        Ke  = (1/h)*[ 1 -1; -1  1];
        be  = zeros(2,1);
        for g = 1:2
            t = gp2(g);  x = node(e) + t*h;
            be = be + gw2(g)*h*f(x)*[1-t; t];
        end
        K(idx,idx) = K(idx,idx) + Ke;
        b(idx)     = b(idx)     + be;
    end

    
    meanOp = h*[0.5; ones(N-1,1); 0.5];
    Aaug   = [K, meanOp; meanOp', 0];
    baug   = [b; Intu];
    sol    = Aaug \ baug;
    xi     = sol(1:N+1);

    
    eL2 = 0;   eH1 = 0;
    for e = 1:ne
        for g = 1:5
            t = gp5(g);  x = node(e) + t*h;
            uh  = xi(e)*(1-t) + xi(e+1)*t;
            duh = (xi(e+1)-xi(e))/h;
            eh  = u(x)  - uh;
            deh = du(x) - duh;
            eL2 = eL2 + gw5(g)*h*eh^2;
            eH1 = eH1 + gw5(g)*h*(eh^2 + deh^2);
        end
    end
    errL2(k) = sqrt(eL2);
    errH1(k) = sqrt(eH1);

    
    if k == 1
        fprintf('%4d   %.4e      -     %.4e      -\n', N, errL2(k), errH1(k));
    else
        ordL2 = log(errL2(k-1)/errL2(k))/log(Nlist(k)/Nlist(k-1));
        ordH1 = log(errH1(k-1)/errH1(k))/log(Nlist(k)/Nlist(k-1));
        fprintf('%4d   %.4e   %6.3f   %.4e   %6.3f\n', ...
                N, errL2(k), ordL2, errH1(k), ordH1);
    end
end
fprintf('=========================================================\n');


