
clear; clc; close all;

%% 测试函数
uexact = @(x,y) (x-1).*(y-1).*sin(x).*sin(y);
f      = @(x,y) 2*(x-1).*(y-1).*sin(x).*sin(y) ...
              - 2*(y-1).*sin(y).*cos(x) ...
              - 2*(x-1).*sin(x).*cos(y);

%% 自检: 差分验证 f = -Δu 
H = 1e-4;  xr = 0.37;  yr = 0.61;
lap = (uexact(xr+H,yr)-2*uexact(xr,yr)+uexact(xr-H,yr))/H^2 ...
    + (uexact(xr,yr+H)-2*uexact(xr,yr)+uexact(xr,yr-H))/H^2;
fprintf('自检: -Δu - f = %.3e (应为 1e-8 量级或更小)\n', -lap - f(xr,yr));

%% 初始网格与计数 
n0 = 4;
[p0, t0] = squaremesh(n0);
nb0 = boundary_nodes(n0);
N0  = size(p0,1);
nT0 = size(t0,1);
nB0 = length(nb0);
nI0 = N0 - nB0;
fprintf('初始网格 (每边 %d 等分): 三角形 %d 个, 结点 %d 个 (内部 %d, 边界 %d)\n', ...
        n0, nT0, N0, nI0, nB0);

%% 加密 3 次求解, 计算 L2/H1 误差与收敛阶
nlist = [4 8 16 32];
Nlev  = 4;
eL2 = zeros(Nlev,1);
eH1 = zeros(Nlev,1);
nT  = zeros(Nlev,1);
nI  = zeros(Nlev,1);
nB  = zeros(Nlev,1);
for lev = 1:Nlev
    n = nlist(lev);
    [p, t] = squaremesh(n);
    nb = boundary_nodes(n);
    N  = size(p,1);
    nT(lev) = size(t,1);
    nB(lev) = length(nb);
    mark = zeros(N,1);
    for q = 1:nB(lev)
        mark(nb(q)) = 1;
    end
    nI(lev) = N - nB(lev);
    ii = zeros(nI(lev),1);
    c = 0;
    for k = 1:N
        if mark(k) == 0
            c = c+1;
            ii(c) = k;
        end
    end
    [K, F] = assemble(p, t, f);
    nIi = nI(lev);
    Kr = zeros(nIi, nIi);
    Fr = zeros(nIi, 1);
    for a = 1:nIi
        Fr(a) = F(ii(a));
        for b2 = 1:nIi
            Kr(a,b2) = K(ii(a), ii(b2));
        end
    end
    ui = Kr \ Fr;
    uh = zeros(N,1);
    for a = 1:nIi
        uh(ii(a)) = ui(a);
    end
    % 误差
    [el, eh] = compute_errors(p, t, uh, uexact);
    eL2(lev) = el;
    eH1(lev) = eh;
end

fprintf('\n');
fprintf('=========================================================================\n');
fprintf(' 总网格数  总内部结点  总边界结点    L2 error      order   H1 error      order\n');
fprintf('-------------------------------------------------------------------------\n');
for lev = 1:Nlev
    if lev == 1
        fprintf('%8d %11d %11d    %.4e        -     %.4e        -\n', ...
                nT(lev), nI(lev), nB(lev), eL2(lev), eH1(lev));
    else
        oL = log(eL2(lev-1)/eL2(lev))/log(2);
        oH = log(eH1(lev-1)/eH1(lev))/log(2);
        fprintf('%8d %11d %11d    %.4e     %6.2f    %.4e     %6.2f\n', ...
                nT(lev), nI(lev), nB(lev), eL2(lev), oL, eH1(lev), oH);
    end
end
fprintf('=========================================================================\n');

%% 初始网格刚度矩阵非零元分布
[K0, F0] = assemble(p0, t0, f);
nnz0 = 0;
rows = zeros(N0*N0, 1);
cols = zeros(N0*N0, 1);
for i = 1:N0
    for j = 1:N0
        if K0(i,j) ~= 0
            nnz0 = nnz0+1;
            rows(nnz0) = i;
            cols(nnz0) = j;
        end
    end
end
rows = rows(1:nnz0);
cols = cols(1:nnz0);
fprintf('\n初始网格刚度矩阵: 规模 %d×%d, 非零元个数 = %d\n', N0, N0, nnz0);
figure;
hold on;
plot(cols, -rows, 'k.');
xlabel('列号 j');
ylabel('行号 -i');
title('初始网格刚度矩阵非零元分布');

%% 初始网格编号图
figure;
hold on;
ne0 = size(t0,1);
for e = 1:ne0
    v1 = t0(e,1);  v2 = t0(e,2);  v3 = t0(e,3);
    plot([p0(v1,1) p0(v2,1) p0(v3,1) p0(v1,1)], ...
         [p0(v1,2) p0(v2,2) p0(v3,2) p0(v1,2)], 'k-');
end
plot(p0(:,1), p0(:,2), 'k.');
xlabel('x');
ylabel('y');
%title('初始网格编号图 (单元形心处为单元号, 结点右上角为结点号)');
USE_TEXT = 1;
if USE_TEXT == 1
    for e = 1:ne0
        v1 = t0(e,1);  v2 = t0(e,2);  v3 = t0(e,3);
        cx = (p0(v1,1)+p0(v2,1)+p0(v3,1))/3;
        cy = (p0(v1,2)+p0(v2,2)+p0(v3,2))/3;
        text(cx, cy, num2str(e));
    end
    for k = 1:N0
        text(p0(k,1)+0.015, p0(k,2)+0.015, num2str(k));
    end
end



%% 局部函数
function [p, t] = squaremesh(n)
idx = @(i,j) j*(n+1) + i;
p = zeros((n+1)*(n+1), 2);
for j = 0:n
    for i = 0:n
        p(idx(i,j)+1, 1) = i/n;
        p(idx(i,j)+1, 2) = j/n;
    end
end
t = zeros(2*n*n, 3);
c = 0;
for j = 0:n-1
    for i = 0:n-1
        v1 = idx(i,j)+1;      v2 = idx(i+1,j)+1;
        v3 = idx(i,j+1)+1;    v4 = idx(i+1,j+1)+1;
        c = c+1;  t(c,1)=v1; t(c,2)=v2; t(c,3)=v4;
        c = c+1;  t(c,1)=v1; t(c,2)=v4; t(c,3)=v3;
    end
end
end

function nb = boundary_nodes(n)
nb = zeros(4*n, 1);
c = 0;
for i = 0:n              % 底边 y=0
    c = c+1;  nb(c) = i+1;
end
for i = 0:n              % 顶边 y=1
    c = c+1;  nb(c) = n*(n+1)+i+1;
end
for j = 1:n-1            % 左边 x=0
    c = c+1;  nb(c) = j*(n+1)+1;
end
for j = 1:n-1            % 右边 x=1
    c = c+1;  nb(c) = j*(n+1)+n+1;
end
end

function [K, F] = assemble(p, t, f)
% 单元刚度阵与载荷向量
N  = size(p,1);
ne = size(t,1);
K  = zeros(N, N);
F  = zeros(N, 1);
for e = 1:ne
    v1 = t(e,1);  v2 = t(e,2);  v3 = t(e,3);
    x1 = p(v1,1); y1 = p(v1,2);
    x2 = p(v2,1); y2 = p(v2,2);
    x3 = p(v3,1); y3 = p(v3,2);
    A2 = (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1);
    A  = abs(A2)/2;
    b1 = y2-y3;  c1 = x3-x2;
    b2 = y3-y1;  c2 = x1-x3;
    b3 = y1-y2;  c3 = x2-x1;
    k11 = (b1*b1 + c1*c1)/(4*A);
    k12 = (b1*b2 + c1*c2)/(4*A);
    k13 = (b1*b3 + c1*c3)/(4*A);
    k22 = (b2*b2 + c2*c2)/(4*A);
    k23 = (b2*b3 + c2*c3)/(4*A);
    k33 = (b3*b3 + c3*c3)/(4*A);
    f12 = f((x1+x2)/2, (y1+y2)/2);
    f23 = f((x2+x3)/2, (y2+y3)/2);
    f31 = f((x3+x1)/2, (y3+y1)/2);
    Fe1 = (A/6)*(f12 + f31);
    Fe2 = (A/6)*(f23 + f12);
    Fe3 = (A/6)*(f31 + f23);
    K(v1,v1) = K(v1,v1) + k11;
    K(v1,v2) = K(v1,v2) + k12;
    K(v1,v3) = K(v1,v3) + k13;
    K(v2,v1) = K(v2,v1) + k12;
    K(v2,v2) = K(v2,v2) + k22;
    K(v2,v3) = K(v2,v3) + k23;
    K(v3,v1) = K(v3,v1) + k13;
    K(v3,v2) = K(v3,v2) + k23;
    K(v3,v3) = K(v3,v3) + k33;
    F(v1) = F(v1) + Fe1;
    F(v2) = F(v2) + Fe2;
    F(v3) = F(v3) + Fe3;
end
end

function [eL2, eH1] = compute_errors(p, t, uh, uexact)
[w, lam] = tri7();
s2L = 0;
s2H = 0;
ne = size(t,1);
for e = 1:ne
    v1 = t(e,1);  v2 = t(e,2);  v3 = t(e,3);
    x1 = p(v1,1); y1 = p(v1,2);
    x2 = p(v2,1); y2 = p(v2,2);
    x3 = p(v3,1); y3 = p(v3,2);
    A2 = (x2-x1)*(y3-y1) - (x3-x1)*(y2-y1);
    u1 = uh(v1);  u2 = uh(v2);  u3 = uh(v3);
    b1 = y2-y3;  c1 = x3-x2;
    b2 = y3-y1;  c2 = x1-x3;
    b3 = y1-y2;  c3 = x2-x1;
    guhx = (u1*b1 + u2*b2 + u3*b3)/A2;
    guhy = (u1*c1 + u2*c2 + u3*c3)/A2;
    for q = 1:7
        l1 = lam(q,1);  l2 = lam(q,2);  l3 = lam(q,3);
        xq = l1*x1 + l2*x2 + l3*x3;
        yq = l1*y1 + l2*y2 + l3*y3;
        uhq = l1*u1 + l2*u2 + l3*u3;
        d = uexact(xq, yq) - uhq;
        ex = (yq-1)*sin(yq)*( sin(xq) + (xq-1)*cos(xq) );
        ey = (xq-1)*sin(xq)*( sin(yq) + (yq-1)*cos(yq) );
        dgx = ex - guhx;
        dgy = ey - guhy;
        s2L = s2L + w(q)*(A2/2)*d^2;
        s2H = s2H + w(q)*(A2/2)*( d^2 + dgx^2 + dgy^2 );
    end
end
eL2 = sqrt(s2L);
eH1 = sqrt(s2H);
end

function [w, lam] = tri7()
s  = sqrt(15);
a  = (6-s)/21;     wa = (155-s)/1200;
bq = (6+s)/21;     wb = (155+s)/1200;
w   = [9/40; wa; wa; wa; wb; wb; wb];
lam = [ 1/3,    1/3,    1/3;
        a,      a,      1-2*a;
        a,      1-2*a,  a;
        1-2*a,  a,      a;
        bq,     bq,     1-2*bq;
        bq,     1-2*bq, bq;
        1-2*bq, bq,     bq ];
end
